import React from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-6">
      <header className="flex justify-between items-center mb-10">
        <h1 className="text-3xl font-bold">Puppy Training</h1>
        <nav className="space-x-6">
          <a href="#" className="hover:underline">Home</a>
          <a href="#guides" className="hover:underline">Free Guides</a>
          <a href="#blog" className="hover:underline">Blog</a>
          <a href="#checkout" className="hover:underline">Buy Course</a>
        </nav>
      </header>

      <section className="text-center py-16 bg-white rounded-2xl shadow mb-10">
        <h2 className="text-4xl font-extrabold mb-4">Train Your Puppy Like a Pro</h2>
        <p className="text-lg mb-6">Learn the fundamentals of puppy training in just 15 minutes a day.</p>
        <div className="space-x-4">
          <Button>Get Free Guide</Button>
          <a href="#checkout"><Button variant="outline">Buy Course</Button></a>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card><CardContent><h3 className="text-xl font-semibold mb-2">Positive Reinforcement</h3><p>Train your pup with gentle, reward-based methods.</p></CardContent></Card>
        <Card><CardContent><h3 className="text-xl font-semibold mb-2">Daily Routines</h3><p>Simple daily habits to reinforce training.</p></CardContent></Card>
        <Card><CardContent><h3 className="text-xl font-semibold mb-2">Science-Based Tips</h3><p>Methods backed by modern animal behavior research.</p></CardContent></Card>
      </section>

      <section id="checkout" className="text-center py-16 bg-white rounded-xl shadow mb-10">
        <h3 className="text-3xl font-bold mb-4">Buy Our Puppy Training Course</h3>
        <p className="text-lg mb-6">Lifetime access to beginner-friendly video lessons and resources.</p>
        <div className="bg-green-100 p-6 max-w-md mx-auto rounded-xl">
          <p className="text-xl font-semibold mb-4">One-time payment: $49</p>
          <a href="https://buy.stripe.com/test_4gw6pW9LZfrw5PGbIK" target="_blank" rel="noopener noreferrer">
            <Button className="w-full">Secure Checkout</Button>
          </a>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-16">
        <p>&copy; {new Date().getFullYear()} Puppy Training. All rights reserved.</p>
      </footer>
    </div>
  );
}
