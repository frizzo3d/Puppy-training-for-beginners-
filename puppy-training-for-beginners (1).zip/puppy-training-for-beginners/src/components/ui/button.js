export function Button({ children, variant = "default", className = "", ...props }) {
  const styles = variant === "outline" 
    ? "border border-blue-500 text-blue-500 hover:bg-blue-100" 
    : "bg-blue-500 text-white hover:bg-blue-600";
  return (
    <button className={`px-4 py-2 rounded-xl font-semibold transition ${styles} ${className}`} {...props}>
      {children}
    </button>
  );
}
